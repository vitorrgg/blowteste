import '#template/js/checkout'
import './custom-js/checkout'

window.ecomPaymentApps = [111223, 1250, 1251, 108091]
